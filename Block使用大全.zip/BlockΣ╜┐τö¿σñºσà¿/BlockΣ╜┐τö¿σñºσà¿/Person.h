//
//  Person.h
//  Block使用大全
//
//  Created by 曹先运 on 17/2/21.
//  Copyright © 2017年 Tee-. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject

//使用2：把block当做方法的参数使用，由方法外部实现，内部调用
//block 无参数
-(void)eat:(void(^)())block;
//block 有参数
-(void)eat:(void(^)(int))block1 apple:(void(^)(int))block2;
//block 有参数，有返回值
-(void)run:(int(^)(int))block;



//使用3：把block 当做方法的返回值，目的是为了替代方法，block由内部实现，外部调用，实现了链式编程
//1.block无返回值，无参数
-(void(^)())eat;
//2.block无返回值，有参数
-(void(^)(int, NSString *))eatMany;
//3.block有返回值，有参数，可以得到返回值
-(int(^)(int))run;


@end
