//
//  Person.m
//  Block使用大全
//
//  Created by 曹先运 on 17/2/21.
//  Copyright © 2017年 Tee-. All rights reserved.
//

#import "Person.h"

@implementation Person

-(void)eat:(void (^)())block
{
    //调用
    block();
}

-(void)eat:(void (^)(int))block1 apple:(void (^)(int))block2
{
    block1(5);
    block2(10);
}

-(void)run:(int (^)(int))block
{
   int a =  block(10);
    NSLog(@"run -- a :%d", a);
}


-(void (^)())eat
{
    return ^{
        NSLog(@"block3 -- block做方法返回值 -- ");
    };
}

-(void (^)(int, NSString *))eatMany
{
    return ^(int m, NSString * str){
      NSLog(@"eat - %d， I am %@", m, str);
    };
}

-(int (^)(int))run
{
    return ^int(int m){
        return m + 10;
    };
}

@end
