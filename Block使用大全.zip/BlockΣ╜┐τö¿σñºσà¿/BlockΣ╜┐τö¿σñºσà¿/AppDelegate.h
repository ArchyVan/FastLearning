//
//  AppDelegate.h
//  Block使用大全
//
//  Created by 曹先运 on 17/2/21.
//  Copyright © 2017年 Tee-. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

