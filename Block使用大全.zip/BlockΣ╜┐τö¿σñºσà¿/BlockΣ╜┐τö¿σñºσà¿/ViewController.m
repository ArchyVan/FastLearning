//
//  ViewController.m
//  Block使用大全
//
//  Created by 曹先运 on 17/2/21.
//  Copyright © 2017年 Tee-. All rights reserved.
//

#import "ViewController.h"
#import "Person.h"


@interface ViewController ()

typedef void(^blockName)();
@property(nonatomic,copy)blockName block1;
@property(nonatomic,copy)void(^blockTest1)();
@property(nonatomic,copy)void(^block2)();
//带参数的
@property(nonatomic,copy)void(^block3)(int);
@property(nonatomic,copy)void(^block4)(int, NSString *,BOOL);
@property(nonatomic,copy)NSString *(^block5)(int, NSString *);

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    [self blockUse1];
    //[self blockUser2];
//    [self blockUse3];
}

-(void)blockUse3
{
    Person * p = [[Person alloc]init];
    //1.block无返回值，无参数
    //p.eat();
    
    //2.block无返回值，有参数
    //p.eatMany(5, @"Happy");
    
    //3.block有返回值，有参数，可以得到返回值，可以在调用的时候把值传过去，再接受处理后的值，和以前的带参且有返回值的方法调用原理一样
    int a = p.run(10);
    NSLog(@"a current value -- %d",a);
}



-(void)blockUser2
{
    //2.把block当做方法的参数使用，外界不能调用，都是方法内部调用，由外部实现
    //可以反向传值
    Person * p = [[Person alloc]init];
    //1.block 无返回值，无参数
//    [p eat:^{
//       NSLog(@"blockUse2 -- 吃东西");
//    }];
    //2.block无返回值，有参数
//    [p eat:^(int m) {
//        NSLog(@"m -- %d",m);
//    } apple:^(int n) {
//        NSLog(@"n -- %d",n);
//    }];
    
//    int(^bb)(int) = ^int(int m){
//        return m+5;
//    };
    
    //3.block有返回值，有参数
    [p run:^int(int m) {
        return m+10;
    }];
    
}



-(void)blockUse1
{
    //1.把block保存到对象中，在合适的时机调用
   // returnType(^blockName)(parameterTypes) = ^(parameters) {
   //     statements
   // };
    void(^blockName)() = ^{
        NSLog(@"-----block第一种用法");
    };
    //调用
    blockName();
//    _blockTest1 = blockName;
    
//    _block3 = ^(int m){
//        NSLog(@"%d -- 米",m);
//    };
//    
//    _block4 = ^(int m, NSString * str, BOOL isYes){
//        NSLog(@"%d, %@, %d",m, str, isYes);
//    };
    
    //带有参数和返回值的block实现
    _block5 = ^NSString *(int m, NSString * str){
        
        return [NSString stringWithFormat:@"%d -- %@",m, str];
    };
    
    
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
//    _blockTest1();
//    _block3(5);
//    _block4(4, @"hello",YES);
    NSString * str = _block5(10, @"Hello");
    NSLog(@"----%@",str);
}



@end
